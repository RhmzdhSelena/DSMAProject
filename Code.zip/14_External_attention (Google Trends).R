###############################################################
# Script: 13A_Trends_vs_Engagement_OptionA.R
# Purpose:
#   Descriptive co-movement between Google Trends attention
#   and Yelp engagement (check-ins), Option A.
###############################################################

rm(list = ls())

# ==============================
# 0) Libraries
# ==============================
library(dplyr)
library(readr)
library(lubridate)
library(ggplot2)
library(tidyr)

# ==============================
# 1) Paths (ADJUST ONLY IF NEEDED)
# ==============================
DATA_DIR <- "C:/Users/selii/OneDrive/Goethe/1. Semester/DSMA/Data/Data"
FIG_DIR  <- file.path(DATA_DIR, "figures_appendix")

dir.create(FIG_DIR, showWarnings = FALSE, recursive = TRUE)

trends_file <- file.path(DATA_DIR, "google_trends_restaurants.csv")
panel_file  <- file.path(DATA_DIR, "internal_panel_final.csv")

# ==============================
# 2) Load Google Trends data
# ==============================
trends <- read_csv(trends_file, show_col_types = FALSE) %>%
  mutate(date = as.Date(date)) %>%
  filter(is.na(isPartial) | isPartial == FALSE)

stopifnot(all(c("date", "search_interest", "business_id") %in% names(trends)))

# Convert 0–100 scale to scale-free "spike" indicator
trends_weekly <- trends %>%
  group_by(business_id) %>%
  mutate(
    q75 = quantile(search_interest, 0.75, na.rm = TRUE),
    spike_week = ifelse(!is.na(search_interest) & search_interest >= q75, 1, 0)
  ) %>%
  ungroup() %>%
  group_by(date) %>%   # already week start from Trends
  summarise(
    n_restaurants = n_distinct(business_id),
    share_spike   = mean(spike_week, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  rename(week = date)

# ==============================
# 3) Load INTERNAL panel (daily)
# ==============================
panel <- read_csv(panel_file, show_col_types = FALSE) %>%
  mutate(date = as.Date(date))

stopifnot("daily_checkins" %in% names(panel))

# Aggregate to matching Sunday-based weeks
panel_weekly <- panel %>%
  mutate(week = floor_date(date, unit = "week", week_start = 7)) %>%
  group_by(week) %>%
  summarise(
    total_checkins = sum(daily_checkins, na.rm = TRUE),
    .groups = "drop"
  )

# ==============================
# 4) Merge & standardize
# ==============================
df <- trends_weekly %>%
  inner_join(panel_weekly, by = "week") %>%
  arrange(week) %>%
  mutate(
    z_attention = as.numeric(scale(share_spike)),
    z_checkins  = as.numeric(scale(total_checkins)),
    z_checkins_lead1 = lead(z_checkins, 1)
  )

# ==============================
# 5) Correlations (diagnostic only)
# ==============================
cor_lag0 <- cor(df$z_attention, df$z_checkins, use = "complete.obs")
cor_lag1 <- cor(df$z_attention, df$z_checkins_lead1, use = "complete.obs")

cat("\n--- Google Trends attention vs total check-ins ---\n")
cat("Correlation (same week, lag 0): ", round(cor_lag0, 3), "\n")
cat("Correlation (next week, lag +1):", round(cor_lag1, 3), "\n\n")

# ==============================
# 6) Plot co-movement (Enhanced Scatter + Smooth + LEGEND)
# ==============================
# Define colors
pal_dark  <- "#00618F"  
pal_mid   <- "#B7C4D1"  
pal_light <- "#DCE3EA"  

p_pretty <- ggplot(df, aes(x = z_attention, y = z_checkins)) +
  # Reference line (not in legend)
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey70") +
  # Points
  geom_point(alpha = 0.4, color = pal_mid, size = 2) +
  # Smooth line with color mapped to create a legend
  geom_smooth(aes(color = "Co-movement Trend"), 
              method = "loess", 
              fill = pal_light,  
              linewidth = 1.2, 
              se = TRUE) +
  # Manually set the color for the legend entry
  scale_color_manual(values = c("Co-movement Trend" = pal_dark)) +
  labs(
    title = "Digital Attention as a Leading Indicator of Engagement",
    subtitle = "Standardized Google Trends Search Spikes vs. Total Yelp Check-ins",
    x = "External Attention (z-score)",
    y = "Physical Engagement (z-score)",
    color = NULL # Removes the title of the legend
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(face = "bold", color = pal_dark),
    panel.grid.minor = element_blank(),
    axis.title = element_text(face = "bold"),
    legend.position = "top" # Places legend at the top to match your other charts
  )

# Save
out_path_pretty <- file.path(FIG_DIR, "Appendix_9_Trends_Scatter.png")
ggsave(out_path_pretty, p_pretty, width = 8, height = 5.5, dpi = 300)